import React, { useState } from "react";
import {
	makeStyles,
	Typography,
	Grid,
	Button,
	TextField,
	withStyles,
	NativeSelect,
} from "@material-ui/core";
import { ButtonCV } from "../../../../components/Button/ButtonCV";

import InputBase from "@material-ui/core/InputBase";

import "./Information.css";

// Data

const informationData = [
	{
		id: 1,
		beforeName: "Mr",
	},
	{
		id: 2,
		beforeName: "Mrs",
	},
	{
		id: 3,
		beforeName: "Miss",
	},
	{
		id: 4,
		beforeName: "Ms",
	},
	{
		id: 5,
		beforeName: "Other",
	},
];

export const Information = ({ contactInfo, setContactInfo }) => {
	// style
	const classes = useStyles();

	const [selected, setSelected] = useState(1);

	const handleChange = (props) => (event) => {
		setContactInfo({ ...contactInfo, [props]: event.target.value });
	};

	const handleClick = (props) => {
		setSelected(props.id);
		setContactInfo({ ...contactInfo, ["nameTitle"]: props.beforeName });
	};

	return (
		<Grid
			container
			direction="column"
			alignItems="flex-start"
			className={classes.root}
		>
			<Grid item className={classes.gridItem}>
				<Typography variant="h6" color="primary" align="left">
					Title
				</Typography>
				<Grid container spacing={2}>
					{informationData.map((info, key) => {
						return (
							<Grid item>
								<Button
									className={`${classes.callenderButton} ${
										selected == info.id ? "selected" : ""
									}`}
									variant="outlined"
									onClick={() => handleClick(info)}
								>
									{info.beforeName}
								</Button>
							</Grid>
						);
					})}
				</Grid>
			</Grid>
			<Grid item className={classes.gridItem}>
				<Typography variant="h6" color="primary" align="left">
					Name
				</Typography>
				<Grid container spacing={2}>
					<Grid item>
						<TextField
							id="outlined-basic"
							label="Name"
							variant="outlined"
							color="primary"
							onChange={handleChange("name")}
						/>
					</Grid>
					<Grid item>
						<TextField
							id="outlined-basic"
							label="Subname"
							variant="outlined"
							color="textSecondary"
							onChange={handleChange("subname")}
						/>
					</Grid>
				</Grid>
			</Grid>
		</Grid>
	);
};

const useStyles = makeStyles((theme) => ({
	root: {
		paddingInline: theme.spacing(1),
	},
	callenderButton: {
		color: "#3E3A00",
		border: "1px solid #3E3A00",
		borderRadius: "3px",
		width: "120px",
		// marginRight: theme.spacing(2),
		textTransform: "none",
		"&.selected": {
			boxShadow: "none",
			backgroundColor: theme.palette.primary.main,
			borderColor: "#005cbf",
			color: "#ffffff",
		},
	},
	gridItem: {
		marginBottom: theme.spacing(3.75),
	},
}));
