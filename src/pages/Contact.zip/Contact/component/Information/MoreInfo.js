import React, { useState } from "react";
import {
	makeStyles,
	Typography,
	Grid,
	Button,
	TextField,
	NativeSelect,
	InputBase,
} from "@material-ui/core";
import { withStyles } from "@material-ui/styles";

export const MoreInfo = ({ contactInfo, setContactInfo, setFormSubmited }) => {
	// const [selected, setSelected] = useState(0);
	const classes = useStyles();

	const handleChange = (props) => (event) => {
		setContactInfo({ ...contactInfo, [props]: event.target.value });
	};

	const handleClick = () => {
		setFormSubmited(true);
	};
	return (
		<Grid container direction="column" align="left">
			<Grid item className={classes.gridItem}>
				<Typography variant="h6" color="primary" align="left">
					Phone
				</Typography>
				<Grid container>
					<TextField
						id="outlined-basic"
						type="number"
						placeholder="999 999 999"
						variant="outlined"
						onChange={handleChange("phone")}
						autoComplete={false}
					/>
				</Grid>
			</Grid>
			<Grid item className={classes.gridItem}>
				<Typography variant="h6" color="primary" align="left">
					Email
				</Typography>
				<Grid container>
					<TextField
						id="outlined-basic"
						type="email"
						placeholder="info@info.com"
						variant="outlined"
						onChange={handleChange("email")}
					/>
				</Grid>
			</Grid>
			<Grid item>
				<Button
					variant="contained"
					color="secondary"
					onClick={handleClick}
				>
					GET YOUR QUOTE
				</Button>
			</Grid>
		</Grid>
	);
};

const BootstrapInput = withStyles((theme) => ({
	root: {
		"label + &": {
			marginTop: theme.spacing(3),
		},
	},
	input: {
		borderRadius: 4,
		position: "relative",
		backgroundColor: theme.palette.background.paper,
		border: "1px solid #ced4da",
		fontSize: 16,
		padding: "18px 26px 18px 12px",
		transition: theme.transitions.create(["border-color", "box-shadow"]),
		// Use the system font instead of the default Roboto font.
		fontFamily: [
			"-apple-system",
			"BlinkMacSystemFont",
			'"Segoe UI"',
			"Roboto",
			'"Helvetica Neue"',
			"Arial",
			"sans-serif",
			'"Apple Color Emoji"',
			'"Segoe UI Emoji"',
			'"Segoe UI Symbol"',
		].join(","),
		"&:focus": {
			borderRadius: 4,
			borderColor: "#80bdff",
			boxShadow: "0 0 0 0.2rem rgba(0,123,255,.25)",
		},
	},
}))(InputBase);

const useStyles = makeStyles((theme) => ({
	gridItem: {
		marginBottom: theme.spacing(3.75),
	},
}));
