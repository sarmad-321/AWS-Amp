import React, { useEffect, useState } from "react";
import { Container } from "@material-ui/core";
// Component's Import

import { PromotionOffer } from "./Promotion/PromotionOffer";

// Import Swiper React components
import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/swiper.min.css";
import "swiper/components/pagination/pagination.min.css";

import "./ContactForm.css";

// import Swiper core and required modules
import SwiperCore, { Mousewheel } from "swiper/core";
import { Storage } from "./Storage/Storage";
import { RequiredSize } from "./Size/RequiredSize";
import { Information } from "./Information/Information";
import { MoreInfo } from "./Information/MoreInfo";

// install Swiper modules
SwiperCore.use([Mousewheel]);

export const ContactFrom = ({
    contactInfo,
    setContactInfo,
    setFormSubmited,
    typeId,
    slideNo,
    setCurrentSlide,
}) => {
    const [swiper, setSwiper] = useState(1);

    useEffect(() => {
        setCurrentSlide(swiper);
    }, [swiper]);

    return (
        <Container maxWidth={false} disableGutters>
            <Swiper
                direction={"vertical"}
                slidesPerView={1}
                spaceBetween={30}
                mousewheel={true}
                className="ContactForm"
                speed={1500}
                touchRatio={2}
                onSlideChange={(e) => setSwiper(e.activeIndex + 1)}
                initialSlide={slideNo}
                followFinger={false}
            >
                <SwiperSlide>
                    <Storage
                        contactInfo={contactInfo}
                        setContactInfo={setContactInfo}
                        typeId={typeId}
                    />
                </SwiperSlide>
                <SwiperSlide>
                    <RequiredSize
                        contactInfo={contactInfo}
                        setContactInfo={setContactInfo}
                    />
                </SwiperSlide>
                <SwiperSlide>
                    <PromotionOffer
                        contactInfo={contactInfo}
                        setContactInfo={setContactInfo}
                    />
                </SwiperSlide>
                <SwiperSlide>
                    <Information
                        contactInfo={contactInfo}
                        setContactInfo={setContactInfo}
                    />
                </SwiperSlide>
                <SwiperSlide>
                    <MoreInfo
                        contactInfo={contactInfo}
                        setContactInfo={setContactInfo}
                        setFormSubmited={setFormSubmited}
                    />
                </SwiperSlide>
            </Swiper>
        </Container>
    );
};
