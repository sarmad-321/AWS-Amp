import React, { useState, useContext, useEffect } from "react";
import {
	Grid,
	makeStyles,
	Typography,
	Button,
	Hidden,
	Card,
	CardContent,
	Container,
	LinearProgress,
} from "@material-ui/core";
import { ArrowBackIosRounded, Phone } from "@material-ui/icons";
import { useHistory } from "react-router-dom";

import { ContactFormDetails } from "./component/ContactFormDetails";
import { ContactFrom } from "./component/ContactFrom";

import { FormDataContext } from "../../Context/Context";
import ShortHeader from "./component/ShortHeader";

export const Contact = ({ setShowHeader }) => {
	const Data = useContext(FormDataContext);
	const [slideNo, setSlideNo] = useState(Data.slideNo);
	const [currentSlide, setCurrentSlide] = useState(1);
	setShowHeader(false);
	const classes = useStyles();

	const FormData = {
		startDate: "",
		duration: "1 week",
		type: Data.name || "Business",
		typeId: Data.id || 1,
		size: "15sqft",
		email: "",
		nameTitle: "Mr ",
		name: "Name",
		subname: "",
		phone: "",
		// slideNo: Data.slideNo,
	};

	const [contactInfo, setContactInfo] = useState(FormData);

	const [formSubmited, setFormSubmited] = useState(false);

	const history = useHistory();

	const handleClick = () => {
		setSlideNo(slideNo);
		history.push("/");
	};
	return (
		<>
			<Grid container zeroMinWidth={true} className={classes.root}>
				<Grid item xs={12} md={12} lg={9}>
					<ShortHeader />
					<Grid className={classes.leftSide}>
						{formSubmited == true ? (
							<ContactFormDetails contactInfo={contactInfo} />
						) : (
							<>
								<Typography
									variant="h4"
									className={classes.leftSideHeadingText}
									color="primary"
									paragraph
								>
									Get A Quote
								</Typography>
								<Typography color="textSecondary" paragraph>
									Try Civixa.ai free before deciding the plan
									or take pay as you go plan
								</Typography>
								<Grid
									container
									spacing={1}
									disableGutters
									direction="row"
									className={classes.progressBarRoot}
								>
									{progressBar.map((item, key) => {
										return (
											<Grid item>
												<p
													className={`${
														classes.progressBar
													} ${
														key <=
															currentSlide - 1 &&
														"selected"
													} `}
												></p>
											</Grid>
										);
									})}
								</Grid>
								<ContactFrom
									contactInfo={contactInfo}
									setContactInfo={setContactInfo}
									setFormSubmited={setFormSubmited}
									typeId={Data.id}
									slideNo={slideNo}
									setCurrentSlide={setCurrentSlide}
								/>
							</>
						)}
					</Grid>
				</Grid>
				<Hidden mdDown>
					<Grid item xs={12} md={3} className={classes.rightSide}>
						<Typography
							variant="h4"
							className={classes.rightSideHeadingText}
							gutterBottom
						>
							Confused About Your Requirements?
						</Typography>
						<Typography
							variant="subtitle1"
							color="secondary"
							className={classes.rightSideParaText}
							paragraph
						>
							Speak to our agent and, we will be able to guide you
							along the process.
						</Typography>
						<Button
							variant="outlined"
							startIcon={<Phone />}
							className={classes.rightSideBtn}
						>
							01733306456
						</Button>
					</Grid>
				</Hidden>
			</Grid>
		</>
	);
};

const progressBar = ["", "", "", "", ""];

// Styling

const useStyles = makeStyles((theme) => ({
	root: {
		height: `100vh`,
		paddingBlock: 0,
	},
	rightSide: {
		backgroundColor: "#064D7B",
		display: "flex",
		flexDirection: "column",
		justifyContent: "center",
		alignItems: "start",
		paddingInline: "3rem",
		paddingBlock: "2rem",
	},
	rightSideHeadingText: {
		fontWeight: "900",
		color: "#ffffff",
		fontSize: theme.spacing(3.5),
	},
	rightSideParaText: {
		fontWeight: "600",
		color: "#ffffff",
	},
	rightSideBtn: {
		backgroundColor: "#ffffff",
		color: theme.palette.primary.main,
		padding: "0.5rem 1.5rem",
		borderRadius: theme.spacing(1),
		"&:hover": {
			backgroundColor: "#ffffff",
			color: theme.palette.primary.main,
		},
	},
	leftSide: {
		display: "flex",
		flexDirection: "column",
		justifyContent: "space-evenly",
		alignItems: "start",
		paddingLeft: "5vw",
		paddingRight: "5vw",
		paddingTop: "0.25rem",
		marginTop: theme.spacing(3.75),
		// [theme.breakpoints.down("sm")]: {
		// 	paddingInline: "10px",
		// 	paddingTop: "0.5rem",
		// },
	},
	leftSideHeadingText: {
		fontWeight: "900",
	},
	detailedGridContainer: {
		paddingInline: "1.5rem",
	},
	backButton: {
		marginBottom: theme.spacing(1),
	},
	progressBarRoot: {
		padding: theme.spacing(0),
	},
	progressBar: {
		width: "30px",
		height: "6px",
		borderRadius: "2px",
		border: "1px solid",
		// backgroundColor: theme.palette.primary.main,
		"&.selected": {
			backgroundColor: theme.palette.primary.main,
			borderColor: theme.palette.primary.main,
		},
	},
}));
